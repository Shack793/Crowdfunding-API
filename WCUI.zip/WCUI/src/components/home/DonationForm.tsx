import React, { useState, useEffect } from 'react';
import { Heart } from 'lucide-react';
import { categoryApi, campaignApi } from '../../services/api';

interface Campaign {
  id: number;
  name: string;
}

const DonationForm: React.FC = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<number | null>(null);
  const [amount, setAmount] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCampaigns = async () => {
      try {
        setLoading(true);
        const response = await campaignApi.getAll();
        setCampaigns(response.data);
        setLoading(false);
      } catch (err) {
        setError('Failed to load campaigns');
        setLoading(false);
        console.error('Error fetching campaigns:', err);
      }
    };

    fetchCampaigns();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCampaign) {
      setError('Please select a campaign');
      return;
    }
    
    if (!amount || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }
    
    try {
      setLoading(true);
      // In a real app, you would redirect to a payment gateway or process the payment
      await campaignApi.donate(selectedCampaign, {
        amount: parseFloat(amount),
      });
      
      // Reset form
      setSelectedCampaign(null);
      setAmount('');
      setError(null);
      setLoading(false);
      
      // Show success message or redirect
      alert('Thank you for your donation!');
    } catch (err) {
      setError('Failed to process donation');
      setLoading(false);
      console.error('Error processing donation:', err);
    }
  };

  return (
    <section className="bg-primary-500 py-8 relative">
      <div className="container-custom">
        <div className="bg-white rounded-lg shadow-lg p-6 md:p-8 -mt-20 relative z-10">
          <h2 className="text-2xl font-bold text-primary-500 mb-6">Rise Your Hand</h2>
          
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="w-full">
              <select
                className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                value={selectedCampaign || ''}
                onChange={(e) => setSelectedCampaign(parseInt(e.target.value))}
              >
                <option value="">Select Campaign</option>
                {campaigns.map((campaign) => (
                  <option key={campaign.id} value={campaign.id}>
                    {campaign.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="w-full">
              <div className="relative">
                <input
                  type="number"
                  placeholder="Amount"
                  className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 pl-16"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  min="1"
                  step="0.01"
                />
                <div className="absolute inset-y-0 left-0 flex items-center px-3 pointer-events-none bg-gray-100 border-r border-gray-300 rounded-l-md">
                  <span className="text-gray-600 font-medium">USD</span>
                </div>
              </div>
            </div>
            
            <button
              type="submit"
              className="btn btn-primary flex items-center justify-center"
              disabled={loading}
            >
              <Heart size={18} className="mr-2" />
              {loading ? 'Processing...' : 'Donate Now'}
            </button>
          </form>
          
          {error && (
            <div className="mt-4 text-red-500 text-sm">{error}</div>
          )}
        </div>
      </div>
    </section>
  );
};

export default DonationForm;