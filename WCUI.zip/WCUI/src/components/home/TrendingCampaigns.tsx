import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { campaignApi } from '../../services/api';

interface Campaign {
  id: number;
  title: string;
  slug: string;
  image: string;
  organization: {
    name: string;
    logo: string;
  };
  amount: {
    raised: number;
    goal: number;
  };
  date: string;
  category: string;
}

const TrendingCampaigns: React.FC = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchTrendingCampaigns = async () => {
      try {
        const response = await campaignApi.getTrending();
        setCampaigns(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching trending campaigns:', error);
        setLoading(false);
      }
    };

    fetchTrendingCampaigns();
  }, []);

  // Mock data for development
  const mockCampaigns: Campaign[] = [
    {
      id: 1,
      title: 'Education gap minimize between rich and poor people.',
      slug: 'education-gap',
      image: 'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=1600',
      organization: {
        name: 'Digital Academy',
        logo: '',
      },
      amount: {
        raised: 100000,
        goal: 270000000,
      },
      date: '03-03-2024',
      category: 'Education',
    },
    {
      id: 2,
      title: 'Gaza Relief Funds(Foodless, Homeless People).',
      slug: 'gaza-relief',
      image: 'https://images.pexels.com/photos/6647035/pexels-photo-6647035.jpeg?auto=compress&cs=tinysrgb&w=1600',
      organization: {
        name: 'White Mind Org',
        logo: '',
      },
      amount: {
        raised: 5000,
        goal: 50000000,
      },
      date: '21-03-2024',
      category: 'Humanitarian',
    },
    {
      id: 3,
      title: 'Educate slum and street children, lighting up futures.',
      slug: 'educate-street-children',
      image: 'https://images.pexels.com/photos/6646917/pexels-photo-6646917.jpeg?auto=compress&cs=tinysrgb&w=1600',
      organization: {
        name: 'Mind Kind Org',
        logo: '',
      },
      amount: {
        raised: 30000,
        goal: 50000000,
      },
      date: '15-03-2024',
      category: 'Education',
    },
  ];

  return (
    <section className="py-16 bg-primary-500 relative">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Trending Campaigns</h2>
          <p className="text-white opacity-80">
            These campaigns are Trending for their activities.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {(loading ? mockCampaigns : campaigns).map((campaign) => (
            <div key={campaign.id} className="card bg-white overflow-hidden transform transition-all duration-300 hover:-translate-y-2">
              <div className="relative">
                <img
                  src={campaign.image}
                  alt={campaign.title}
                  className="w-full h-56 object-cover"
                />
                <div className="absolute top-4 left-4 bg-primary-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                  {campaign.category}
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm text-gray-500">{campaign.date}</span>
                  <span className="text-sm font-medium">{campaign.organization.name}</span>
                </div>
                
                <h3 className="text-xl font-bold mb-4 line-clamp-2">
                  <Link to={`/campaign/${campaign.slug}`} className="hover:text-primary-500 transition-colors">
                    {campaign.title}
                  </Link>
                </h3>
                
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">${(campaign.amount.raised).toLocaleString()} Raised</span>
                    <span className="text-gray-500">Goal: ${(campaign.amount.goal).toLocaleString()} USD</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-primary-500 h-2 rounded-full"
                      style={{
                        width: `${Math.min(
                          (campaign.amount.raised / campaign.amount.goal) * 100,
                          100
                        )}%`,
                      }}
                    ></div>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <Link
                    to={`/campaign/${campaign.slug}`}
                    className="text-primary-500 font-medium hover:underline"
                  >
                    View Details
                  </Link>
                  <button className="flex items-center text-primary-500 hover:text-primary-600 transition-colors">
                    <Heart size={18} className="mr-1" />
                    Donate
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrendingCampaigns;