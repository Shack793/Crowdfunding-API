import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="rounded-lg overflow-hidden">
            <img
              src="https://images.pexels.com/photos/1250452/pexels-photo-1250452.jpeg?auto=compress&cs=tinysrgb&w=1600"
              alt="Child in need"
              className="w-full h-auto object-cover rounded-lg transform transition-transform duration-500 hover:scale-105"
            />
          </div>
          
          <div>
            <h2 className="text-3xl font-bold mb-6 text-gray-800">We are here to help you!</h2>
            <p className="text-gray-600 mb-6">
              WaltergateFund is an organization that provides donations to helpless children, women,
              and poor people in order for them to become self-sufficient. RiseLab's
              humanitarian projects are committed to helping around the world.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-start">
                <CheckCircle className="text-primary-500 mr-3 mt-1 flex-shrink-0" size={20} />
                <p className="text-gray-700">
                  We've helped families and communities get back on their feet quickly.
                </p>
              </div>
              
              <div className="flex items-start">
                <CheckCircle className="text-primary-500 mr-3 mt-1 flex-shrink-0" size={20} />
                <p className="text-gray-700">
                  WaltergateFund fundraising tools make it easy for you to create, share, and raise
                  money for your campaign.
                </p>
              </div>
              
              <div className="flex items-start">
                <CheckCircle className="text-primary-500 mr-3 mt-1 flex-shrink-0" size={20} />
                <p className="text-gray-700">
                  WaltergateFund helps you easily share your story far and wide over email, text,
                  and social media to rally support for your cause.
                </p>
              </div>
            </div>
            
            <Link 
              to="/campaigns" 
              className="btn btn-primary inline-block"
            >
              EXPLORE CAMPAIGNS
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;