import React from 'react';
import { Recycle } from 'lucide-react';

interface RiseLabLogoProps {
  className?: string;
}

const RiseLabLogo: React.FC<RiseLabLogoProps> = ({ className = '' }) => {
  return (
    <div className={`flex items-center ${className}`}>
      <Recycle className="text-primary-500 w-8 h-8 mr-2" />
      <span className="text-xl font-bold">
        <span className="text-primary-500">Waltergate</span>
        <span className="text-gray-800">Fund</span>
      </span>
    </div>
  );
};

export default RiseLabLogo;