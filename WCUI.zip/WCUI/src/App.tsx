import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import CampaignPage from './pages/CampaignPage';
import FaqPage from './pages/FaqPage';
import VolunteerPage from './pages/VolunteerPage';
import SuccessStoryPage from './pages/SuccessStoryPage';
import StartCampaignPage from './pages/StartCampaignPage';
import NotFoundPage from './pages/NotFoundPage';

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/campaign" element={<CampaignPage />} />
      <Route path="/faq" element={<FaqPage />} />
      <Route path="/volunteer" element={<VolunteerPage />} />
      <Route path="/success-story" element={<SuccessStoryPage />} />
      <Route path="/start-campaign" element={<StartCampaignPage />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}

export default App;